import re

with open('app.py', 'r') as f:
    content = f.read()

# Find the prediction block
start = '                    st.markdown("### Current Market Estimate")'
end = '                    st.warning("**Important Note**: This is an estimated market value based on current property listings and historical machine-learning data. Listing prices are asking prices and may differ from actual negotiated or registered transaction prices. This estimate is not a legal property valuation or guaranteed sale price.")'

new_block = """                    
                    st.markdown("## Property Details")
                    st.markdown(f\"\"\"
                    * **City:** {city}
                    * **Location:** {location}
                    * **Property Type:** {property_type}
                    * **BHK:** {bhk}
                    * **Area:** {area} sq.ft.
                    * **Bathrooms:** {bathrooms}
                    \"\"\")
                    
                    # Fetch live market data
                    live_listings_df = fetch_live_market_data(city, location, property_type, bhk)
                    
                    # Analyze comparables
                    analyzer = ComparableAnalyzer(live_listings_df)
                    comp_result = analyzer.find_comparables(city, location, property_type, bhk, area)
                    
                    if comp_result['status'] == 'SUCCESS':
                        comp_estimate = comp_result['estimate']
                        final_estimate = (prediction + comp_estimate) / 2
                        comp_display = f"`{format_indian_currency(comp_estimate)}`"
                        final_display = f"`{format_indian_currency(final_estimate)}`"
                        comp_listings = comp_result['count']
                        comp_median = f"₹{comp_result['median_sqft_price']:,.2f}"
                    elif comp_result['status'] == 'LIVE DATA PROVIDER NOT CONFIGURED':
                        comp_display = "`Not available (API Not Configured)`"
                        final_display = f"`{format_indian_currency(prediction)}`"
                        comp_listings = 0
                        comp_median = "N/A"
                    else:
                        comp_display = "`Not available (Insufficient listings)`"
                        final_display = f"`{format_indian_currency(prediction)}`"
                        comp_listings = comp_result['count']
                        comp_median = "N/A"
                        
                    st.markdown("## Historical ML Estimate")
                    st.markdown(f"`{format_indian_currency(prediction)}`")
                    
                    st.markdown("## Current Comparable Estimate")
                    st.markdown(comp_display)
                    
                    st.markdown("## Final Current Market Estimate")
                    st.markdown(final_display)
                    
                    st.markdown("## Current Market Data")
                    st.markdown(f\"\"\"
                    * **Comparable listings:** {comp_listings}
                    * **Median ₹/sq.ft.:** {comp_median}
                    * **Data retrieved:** {datetime.now().strftime('%d-%m-%Y %H:%M')}
                    * **Source:** ConfiguredAPIDataProvider (Mock)
                    \"\"\")
                    
                    if st.button("🔄 Refresh Current Market Data"):
                        fetch_live_market_data.clear()
                        st.rerun()

                    st.warning("**Important Note**: This is an estimated market value based on recently retrieved property listings and historical machine-learning data. Listing prices are asking prices and may differ from actual negotiated or registered transaction prices. This is not a legal valuation or guaranteed sale price.")
"""

pattern = re.compile(re.escape(start) + r'.*?' + re.escape(end), re.DOTALL)
content = pattern.sub(new_block, content)

with open('app.py', 'w') as f:
    f.write(content)
